package br.com.fiap.sprint.repository;

import br.com.fiap.sprint.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
}
